var count = 2

while (count < 101)
{
    document.write(count + "<br>");
    count = count + 2
}